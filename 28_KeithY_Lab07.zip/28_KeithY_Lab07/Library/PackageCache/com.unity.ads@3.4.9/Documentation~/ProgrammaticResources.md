# Unified Auction resources
Review the supplemental material in this section to fine-tune your programmatic ads implementation.

* [Supported creative formats](ProgrammaticResourcesCreativeFormats.md)
* [Data privacy](ProgrammaticResourcesDataPrivacy.md)
* [IAB content categories](ProgrammaticResourcesCategoryMapping.md)
* [FAQs](ProgrammaticResourcesFaq.md)